############################
#####Wordpress installation#
############################

echo "ON WHICH PATH YOU WANT TO INSTALL after $HOME/";

read loc

unzip unzip.zip


cp -r * $HOME/$loc


######
#Instattion Main
####

apt-get update && apt-get install php


echo "Successfully Wordpress installed in $loc directory";

echo "You Can Start Wordpress with "
echo "php -S 127.0.0.1:4444 -t $loc"


