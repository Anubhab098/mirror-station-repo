#SHELL PHISH INSTALLATING 
#COPYRIGHT TO LINUXSKILLS
#github.com/linuxskills


echo "Pls Wait Installating shell phish for you";

unzip unzip.zip

mv shellphish $HOME/

cd $HOME/shellphish

chmod +x *

echo "SHELL PHISH IS NOW INSTALLED  AND YOU CAN USE IT WITH ./shellphish.sh";


