#GITHUB REPO ANUBHAB FAST MIRROR UK
#COPYRIGHT LINUXSKILLS

# colors

# colors

red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
reset='\033[0m'


#main

#status

echo " [*] installating saycheese pls wait"
           
#main-install

apt install -y php openssh

#unziping

unzip unzip.zip

# moving the package

mv saycheese $HOME/

#Done

echo " Done ! All Packages installated in your $HOME DIRECTORY";
           

