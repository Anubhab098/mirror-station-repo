#phpmyadmin installation script repo hosted on files-anubhab-hosted custom repo

echo "Pls Wait Phpmyadmin is installing";


echo "phpmyadmin install location in $HOME/ If It Home leave it empty";
read loc


stat="$HOME/"

#installatig required pacakges

apt install -y php

#unziping package

unzip unzip.zip

#mv pacakege to loc dir

mv phpmyadmin $HOME/$loc;
rm -rf unzip.zip

#Displaying logging instaructions

echo "Thanks For Installing phpmyadmin From our Repo ";
                            

echo "You Need To Paste This command for phpmyadmin working in browser";

echo "php -S 127.0.0.1:4444 -t $HOME/$loc/phpmyadmin";

echo "make sure you make mysql running";

